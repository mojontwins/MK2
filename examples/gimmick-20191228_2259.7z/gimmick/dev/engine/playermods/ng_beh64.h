	p_ax = PLAYER_AX;
	p_rx = PLAYER_RX;
	if (possee) {
		if (at1 & 64) {
			p_ax = PLAYER_AX_ALT;
			p_rx = PLAYER_RX_ALT;
		}
	}