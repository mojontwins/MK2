// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
extern unsigned char sprite_e [];
 
#asm
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_a
        defb 0, 224
        defb 31, 192
        defb 15, 224
        defb 31, 192
        defb 28, 192
        defb 59, 128
        defb 59, 128
        defb 123, 0
        defb 124, 0
        defb 127, 0
        defb 111, 0
        defb 31, 128
        defb 63, 128
        defb 31, 128
        defb 47, 128
        defb 0, 192
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_b
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 240, 7
        defb 64, 3
        defb 184, 3
        defb 48, 3
        defb 48, 1
        defb 68, 1
        defb 254, 0
        defb 254, 0
        defb 142, 0
        defb 254, 0
        defb 252, 1
        defb 248, 3
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_1_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_a
        defb 0, 136
        defb 55, 128
        defb 31, 192
        defb 31, 192
        defb 28, 192
        defb 59, 128
        defb 58, 128
        defb 122, 0
        defb 124, 0
        defb 127, 0
        defb 111, 0
        defb 31, 128
        defb 63, 128
        defb 57, 128
        defb 22, 192
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_b
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 240, 7
        defb 64, 3
        defb 184, 3
        defb 32, 3
        defb 32, 1
        defb 68, 1
        defb 254, 0
        defb 254, 0
        defb 30, 0
        defb 254, 0
        defb 252, 1
        defb 248, 3
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_2_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_a
        defb 0, 24
        defb 103, 0
        defb 63, 128
        defb 31, 192
        defb 28, 192
        defb 59, 128
        defb 56, 128
        defb 120, 0
        defb 124, 0
        defb 111, 0
        defb 55, 128
        defb 15, 192
        defb 63, 128
        defb 62, 128
        defb 29, 192
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_b
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 240, 7
        defb 64, 3
        defb 184, 3
        defb 136, 3
        defb 136, 1
        defb 68, 1
        defb 254, 0
        defb 254, 0
        defb 62, 0
        defb 254, 0
        defb 60, 1
        defb 216, 3
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_3_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_a
        defb 0, 248
        defb 3, 240
        defb 12, 224
        defb 11, 128
        defb 90, 0
        defb 90, 0
        defb 124, 0
        defb 127, 0
        defb 60, 0
        defb 24, 128
        defb 56, 128
        defb 24, 192
        defb 28, 192
        defb 3, 128
        defb 120, 0
        defb 0, 135
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_b
        defb 0, 63
        defb 192, 15
        defb 64, 7
        defb 184, 3
        defb 32, 3
        defb 32, 3
        defb 68, 1
        defb 252, 1
        defb 124, 1
        defb 56, 1
        defb 54, 0
        defb 54, 0
        defb 118, 0
        defb 230, 0
        defb 0, 25
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_4_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_a
        defb 0, 252
        defb 3, 240
        defb 15, 224
        defb 15, 224
        defb 2, 192
        defb 29, 192
        defb 12, 192
        defb 12, 128
        defb 34, 128
        defb 127, 0
        defb 127, 0
        defb 113, 0
        defb 127, 0
        defb 63, 128
        defb 31, 192
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_b
        defb 0, 7
        defb 248, 3
        defb 240, 7
        defb 248, 3
        defb 56, 3
        defb 220, 1
        defb 220, 1
        defb 222, 0
        defb 62, 0
        defb 254, 0
        defb 246, 0
        defb 248, 1
        defb 252, 1
        defb 248, 1
        defb 244, 1
        defb 0, 3
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_5_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_a
        defb 0, 252
        defb 3, 240
        defb 15, 224
        defb 15, 224
        defb 2, 192
        defb 29, 192
        defb 4, 192
        defb 4, 128
        defb 34, 128
        defb 127, 0
        defb 127, 0
        defb 120, 0
        defb 127, 0
        defb 63, 128
        defb 31, 192
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_b
        defb 0, 17
        defb 236, 1
        defb 248, 3
        defb 248, 3
        defb 56, 3
        defb 220, 1
        defb 92, 1
        defb 94, 0
        defb 62, 0
        defb 254, 0
        defb 246, 0
        defb 248, 1
        defb 252, 1
        defb 156, 1
        defb 104, 3
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_6_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_a
        defb 0, 252
        defb 3, 240
        defb 15, 224
        defb 15, 224
        defb 2, 192
        defb 29, 192
        defb 17, 192
        defb 17, 128
        defb 34, 128
        defb 127, 0
        defb 127, 0
        defb 124, 0
        defb 127, 0
        defb 60, 128
        defb 27, 192
        defb 0, 224
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_b
        defb 0, 24
        defb 230, 0
        defb 252, 1
        defb 248, 3
        defb 56, 3
        defb 220, 1
        defb 28, 1
        defb 30, 0
        defb 62, 0
        defb 246, 0
        defb 236, 1
        defb 240, 3
        defb 252, 1
        defb 124, 1
        defb 184, 3
        defb 0, 7
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_7_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_a
        defb 0, 252
        defb 3, 240
        defb 2, 224
        defb 29, 192
        defb 4, 192
        defb 4, 192
        defb 34, 128
        defb 63, 128
        defb 62, 128
        defb 28, 128
        defb 108, 0
        defb 108, 0
        defb 110, 0
        defb 103, 0
        defb 0, 152
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_b
        defb 0, 31
        defb 192, 15
        defb 48, 7
        defb 208, 1
        defb 90, 0
        defb 90, 0
        defb 62, 0
        defb 254, 0
        defb 60, 0
        defb 24, 1
        defb 28, 1
        defb 24, 3
        defb 56, 3
        defb 192, 1
        defb 30, 0
        defb 0, 225
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_8_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_a
        defb 0, 252
        defb 3, 240
        defb 15, 224
        defb 29, 192
        defb 25, 192
        defb 25, 192
        defb 27, 192
        defb 15, 224
        defb 15, 224
        defb 21, 128
        defb 32, 128
        defb 16, 192
        defb 0, 224
        defb 0, 224
        defb 30, 192
        defb 0, 193
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_b
        defb 0, 127
        defb 128, 31
        defb 224, 15
        defb 112, 7
        defb 48, 7
        defb 48, 7
        defb 176, 7
        defb 224, 15
        defb 224, 15
        defb 64, 31
        defb 0, 7
        defb 8, 3
        defb 4, 1
        defb 0, 1
        defb 120, 3
        defb 0, 131
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_9_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_a
        defb 0, 254
        defb 1, 248
        defb 7, 240
        defb 14, 224
        defb 12, 224
        defb 12, 224
        defb 13, 224
        defb 7, 240
        defb 7, 240
        defb 2, 248
        defb 0, 224
        defb 16, 192
        defb 32, 128
        defb 16, 128
        defb 14, 224
        defb 0, 225
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_b
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 184, 3
        defb 152, 3
        defb 152, 3
        defb 216, 3
        defb 240, 7
        defb 240, 7
        defb 168, 1
        defb 4, 1
        defb 8, 3
        defb 0, 7
        defb 0, 15
        defb 112, 7
        defb 0, 135
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_10_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_a
        defb 0, 255
        defb 0, 248
        defb 7, 224
        defb 31, 192
        defb 51, 128
        defb 45, 128
        defb 97, 0
        defb 105, 0
        defb 115, 0
        defb 127, 0
        defb 127, 0
        defb 61, 128
        defb 63, 128
        defb 29, 192
        defb 13, 224
        defb 0, 242
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_b
        defb 0, 255
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 152, 3
        defb 104, 3
        defb 12, 1
        defb 76, 1
        defb 156, 1
        defb 252, 1
        defb 252, 1
        defb 252, 1
        defb 252, 1
        defb 220, 3
        defb 216, 3
        defb 0, 39
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_11_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_a
        defb 0, 248
        defb 7, 224
        defb 31, 192
        defb 51, 128
        defb 45, 128
        defb 97, 0
        defb 101, 0
        defb 115, 0
        defb 127, 0
        defb 127, 0
        defb 62, 128
        defb 63, 128
        defb 30, 192
        defb 7, 224
        defb 0, 248
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_b
        defb 0, 63
        defb 192, 15
        defb 240, 7
        defb 152, 3
        defb 104, 3
        defb 12, 1
        defb 44, 1
        defb 156, 1
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 254, 0
        defb 222, 0
        defb 108, 1
        defb 0, 147
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_12_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_a
        defb 0, 248
        defb 7, 224
        defb 1, 192
        defb 63, 128
        defb 17, 128
        defb 51, 128
        defb 17, 128
        defb 63, 128
        defb 1, 192
        defb 15, 192
        defb 35, 128
        defb 96, 0
        defb 23, 0
        defb 0, 192
        defb 56, 131
        defb 0, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_b
        defb 0, 31
        defb 128, 7
        defb 240, 3
        defb 224, 1
        defb 24, 1
        defb 48, 1
        defb 24, 1
        defb 240, 1
        defb 240, 0
        defb 2, 0
        defb 206, 0
        defb 0, 1
        defb 192, 3
        defb 28, 1
        defb 0, 227
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_13_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_a
        defb 0, 248
        defb 7, 224
        defb 3, 192
        defb 63, 128
        defb 17, 128
        defb 57, 128
        defb 17, 128
        defb 63, 128
        defb 3, 0
        defb 79, 0
        defb 115, 0
        defb 0, 128
        defb 3, 192
        defb 56, 128
        defb 0, 199
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_b
        defb 0, 31
        defb 128, 7
        defb 240, 3
        defb 224, 1
        defb 24, 1
        defb 144, 1
        defb 24, 1
        defb 240, 1
        defb 240, 3
        defb 128, 3
        defb 196, 1
        defb 6, 0
        defb 232, 0
        defb 0, 3
        defb 28, 193
        defb 0, 227
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_14_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_a
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_b
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_15_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_a
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_b
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
    ._sprite_16_c
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
; Extra sprites ahead...
    ._sprite_e
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 255, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
        defb 0, 255
 
#endasm
 
