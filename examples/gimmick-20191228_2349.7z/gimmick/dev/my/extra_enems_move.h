// MT MK2 ZX v1.0 
// Copyleft 2010-2015, 2019 by The Mojon Twins

// Add here update code for custom enemies. You can add new "case" upon the 
// enemy movement type (5-8, 11-14 free), like this:

/*
	case 5:
		// static, idle, dummy enemy
		active = animate = 1;
		break;
*/

