// MT Engine MK2 v0.90b
// Copyleft 2016 the Mojon Twins

// extern_e.h
// Extended External custom code to be run from a script

void do_extern_action (unsigned char n, unsigned m) {
	// Add custom code here.
}
