Aqu� antes hab�a un *colocador*. Ahora en `..\utils\` tienes un *ponedor*, que es m�s mejor y, por tanto, menos peor.

Escribe en tu terminal

```
	..\utils\ponedor.exe
```

y sigue las instrucciones. Lo agradecer�s, sobre todo si has sufrido el Colocador.

No necesitas m�s, ponedor.exe emplea los mismos recursos que colocador - con algunos extras, como soportar `*.png` para el tileset.
