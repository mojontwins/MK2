// Sprites.h
// Generado por SprCnv de la Churrera
// Copyleft 2010 The Mojon Twins
 
extern unsigned char sprite_1_a []; 
extern unsigned char sprite_1_b []; 
extern unsigned char sprite_1_c []; 
extern unsigned char sprite_2_a []; 
extern unsigned char sprite_2_b []; 
extern unsigned char sprite_2_c []; 
extern unsigned char sprite_3_a []; 
extern unsigned char sprite_3_b []; 
extern unsigned char sprite_3_c []; 
extern unsigned char sprite_4_a []; 
extern unsigned char sprite_4_b []; 
extern unsigned char sprite_4_c []; 
extern unsigned char sprite_5_a []; 
extern unsigned char sprite_5_b []; 
extern unsigned char sprite_5_c []; 
extern unsigned char sprite_6_a []; 
extern unsigned char sprite_6_b []; 
extern unsigned char sprite_6_c []; 
extern unsigned char sprite_7_a []; 
extern unsigned char sprite_7_b []; 
extern unsigned char sprite_7_c []; 
extern unsigned char sprite_8_a []; 
extern unsigned char sprite_8_b []; 
extern unsigned char sprite_8_c []; 
extern unsigned char sprite_9_a []; 
extern unsigned char sprite_9_b []; 
extern unsigned char sprite_9_c []; 
extern unsigned char sprite_10_a []; 
extern unsigned char sprite_10_b []; 
extern unsigned char sprite_10_c []; 
extern unsigned char sprite_11_a []; 
extern unsigned char sprite_11_b []; 
extern unsigned char sprite_11_c []; 
extern unsigned char sprite_12_a []; 
extern unsigned char sprite_12_b []; 
extern unsigned char sprite_12_c []; 
extern unsigned char sprite_13_a []; 
extern unsigned char sprite_13_b []; 
extern unsigned char sprite_13_c []; 
extern unsigned char sprite_14_a []; 
extern unsigned char sprite_14_b []; 
extern unsigned char sprite_14_c []; 
extern unsigned char sprite_15_a []; 
extern unsigned char sprite_15_b []; 
extern unsigned char sprite_15_c []; 
extern unsigned char sprite_16_a []; 
extern unsigned char sprite_16_b []; 
extern unsigned char sprite_16_c []; 
 
#asm
    ._spriteset
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_1_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_1_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_1_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_2_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_2_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_2_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_3_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_3_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_3_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_4_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_4_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_4_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_5_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_5_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_5_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_6_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_6_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_6_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_7_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_7_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_7_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_8_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_8_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_8_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_9_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_9_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_9_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_10_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_10_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_10_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_11_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_11_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_11_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_12_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_12_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_12_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_13_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_13_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_13_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_14_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_14_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_14_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_15_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_15_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_15_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_16_a
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_16_b
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
    ._sprite_16_c
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
        defb 85, 170
 
#endasm
 
